package com.curso.android.app.projectofinalticmas.model;

public class TextComparisonModel {
    public boolean areTextsEqual(String text1, String text2) {
        return text1.equalsIgnoreCase(text2);
    }

}
