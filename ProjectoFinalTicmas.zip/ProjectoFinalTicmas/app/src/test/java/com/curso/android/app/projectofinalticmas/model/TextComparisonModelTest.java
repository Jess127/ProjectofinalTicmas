package com.curso.android.app.projectofinalticmas.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class TextComparisonModelTest {
    @Test
    public void areTextsEqual() {
    }
}